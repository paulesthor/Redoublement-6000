import sys
import os

# 1. REMPLACE 'TonNomdUtilisateur' par ton vrai nom d'utilisateur PythonAnywhere !
path = '/home/TonNomdUtilisateur/mysite'

if path not in sys.path:
    sys.path.append(path)

from main import app
from a2wsgi import ASGIMiddleware

# PythonAnywhere cherche une variable 'application'
application = ASGIMiddleware(app)
