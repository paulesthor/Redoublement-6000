# 🐍 Guide Déploiement PythonAnywhere (Version "Toujours Actif")

Cette version du site est adaptée pour **PythonAnywhere**, qui est une alternative à Render.
L'avantage : La version gratuite ne "dort" pas (pas de latence de 30s).
L'inconvénient : Il faut cliquer sur un bouton "Extend" tous les 3 mois.

## 1. Créer le compte
1.  Va sur [pythonanywhere.com](https://www.pythonanywhere.com/).
2.  Crée un compte "Beginner" (Gratuit).

## 2. Envoyer les fichiers
Il y a plusieurs méthodes, la plus simple sans commandes git :
1.  Va dans l'onglet **Files**.
2.  Crée un dossier `mysite` (à gauche).
3.  Upload tous les fichiers *de ce dossier "test Python"* dedans (`main.py`, `requirements.txt`, les dossiers `templates`, `maquettes`, etc.).
    *   *Astuce* : Tu peux aussi zipper tout le dossier "test Python", l'uploader, et ouvrir une **Console Bash** pour faire `unzip ton_fichier.zip`.

## 3. Installer les dépendances
1.  Ouvre une **Bash Console** (depuis le Dashboard).
2.  Tape :
    ```bash
    pip3.10 install -r mysite/requirements.txt
    ```
    (Remplace `3.10` par la version de Python que tu as choisie si différent).

## 4. Configurer le Web App
1.  Va dans l'onglet **Web**.
2.  Clique sur **Add a new web app**.
3.  Clique **Next**, choisis **Manual Configuration** (pas "Flask" ni "Django", car on utilise FastAPI).
4.  Choisis **Python 3.10** (ou la version que tu as installée).
5.  Clique **Next**.

## 5. Configurer le fichier WSGI
1.  Dans l'onglet **Web**, cherche la section **Code**.
2.  Clique sur le lien à côté de **WSGI configuration file** (ça ressemble à `/var/www/tonnom_pythonanywhere_com_wsgi.py`).
3.  **EFFACE TOUT** ce qu'il y a dans ce fichier.
4.  Copie-colle le contenu du fichier `wsgi_pour_pythonanywhere.py` que j'ai créé pour toi.
5.  **Important** : Dans le code collé, change `/home/TonNomdUtilisateur/mysite` par ton vrai chemin (ton nom d'utilisateur est écrit en haut à droite).
6.  Clique sur **Save**.

## 6. Lancer !
1.  Retourne dans l'onglet **Web**.
2.  Clique sur le gros bouton vert **Reload tonnom.pythonanywhere.com**.
3.  Clique sur le lien de ton site (en haut). Ça marche ! 🎉
